<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "MyMilkSupply";

// Connection
$connection = new mysqli($servername, $username, $password, $database);

$password = "";
$username = "";
$errorMessage = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize user input to prevent SQL injection
    $username = mysqli_real_escape_string($connection, $_POST["username"]);
    $password = mysqli_real_escape_string($connection, $_POST["password"]);

    // Query to check if the user exists
    $query = "SELECT * FROM users_consumer WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($connection, $query);

    // Check if there's a matching user
    if ($row = mysqli_fetch_assoc($result)) {
        // Redirect to the dashboard or home page upon successful login
        header("location: /MilkSupply/consumer/index.php");
        exit;
    } else {
        $errorMessage = "Invalid username or password";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="/MilkSupply/style.css">
    <title>Login Form</title>
    <style>
     body {
  margin-top: 2px;
  height: 90vh;
  width: 100vw;
  background-image: url('/MilkSupply/bg_image.png');
  background-size: cover;
  backdrop-filter: blur(10px);
}

   
    .login-container {
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        padding: 20px;
        max-width: 300px;
        width: 100%;
        text-align: center;
        margin:auto;
        margin-top:200px;
    }

        .login-form label {
            display: block;
            margin-bottom: 8px;
        }

        .login-form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        .login-form input[type="submit"] {
            background-color: #3498db;
            color: #fff;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-form input[type="submit"]:hover {
            background-color: #0d6efd;
        }

        .error-box {
            color: #ff0000;
            margin-top: 10px;
        }
    </style>
</head>
<body>
<nav class="navbar">
        <div class="nav-container">
        <a class="navbar-home" href="/MilkSupply/index.php">
                <i class="fas fa-house"></i> 
                Home
        </a>
        </div>
        <h2 class="heading">Milk Supply System</h2>
    </nav>
    <div class="login-container login">
        <h1>Login</h1>

        <?php
        // Display error message if login fails
        if (isset($errorMessage)) {
            echo '<div class="error-box">' . $errorMessage . '</div>';
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="login-form">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required>

            <label for="password">Password</label>
            <input type="password" name="password" id="password" required>

            <input type="submit" name="login" value="Login">
        </form>
    </div>
</body>
</html>
